Hooks:PostHook( WeaponFactoryTweakData, "init", "seriotweak", function(self)
 
self.parts.wpn_fps_snp_m95_barrel_long.stats = {damage = 2500, spread = 2, recoil = -3, concealment = -10}
self.parts.wpn_fps_snp_m95_barrel_short.stats = {damage = -2500, spread = -4, recoil = -1, concealment = 10, total_ammo = 5}
self.parts.wpn_fps_snp_m95_barrel_suppressed.stats = {damage = -2500, recoil = 8, concealment = -1}

end )