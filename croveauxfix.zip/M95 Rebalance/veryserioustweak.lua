local old_init = WeaponTweakData.init

function WeaponTweakData:init(tweak_data)
    old_init(self, tweak_data)

self.m95.AMMO_MAX = 5
self.m95.CLIP_AMMO_MAX = 10
self.m95.AMMO_PICKUP = {0, 0}

end